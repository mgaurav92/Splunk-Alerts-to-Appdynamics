
Splunk Alerts to Appdynamics Add-on
====================================

* **Author:** Gaurav Maniar
* **Add-on Version:** 1.0.0

### Description ###
 
An alert action to create a Custom Event on Appdynamics when the Splunk alert is triggered.